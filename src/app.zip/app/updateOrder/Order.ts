export class Order {
   
    orderId: number;
    bookId: number;
    quantity:number;
    subToatl:number;
    total:number;
    orderStatus:string;
    paymentMethod:String;
}