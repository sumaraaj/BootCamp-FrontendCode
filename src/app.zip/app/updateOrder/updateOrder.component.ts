import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from '../order.service';
@Component({
  selector: 'app-updateorder',
  templateUrl: './updateorder.component.html',
  styleUrls: ['./updateorder.component.scss']
})
export class UpdateorderComponent implements OnInit {

  OrderInfo: any={};
  orderId: number;
  quantity: number;
message: string;
errormessage: string;

  constructor(private orderservice: OrderService, private router:Router) { }

  ngOnInit(): void {
  }
     updateOrder(){

    this.orderservice.updateOrder(this.orderId, this.quantity).subscribe(
      response => this.handleSuccessfulResponse(response),
      
      );
  }
  handleSuccessfulResponse(response) {
    //this.message = response;
   // this.router.navigate(['/success']);
  }}
      //console.log( data);
    //this.message = data;
      //this.errormessage = data;
    //this.router.navigate(['/success']);
    //},
    //error =>this.message=error);;
    //}
 // }
